# FacePort 2K (starter)

Android Studio Kotlin project for preparing extracted cyberface assets for NBA 2K20 Mobile.

## Current implementation
- Select a Wavefront OBJ mesh through Android's document picker.
- Select multiple texture files.
- Count OBJ vertex and face records for a basic validation pass.
- Bundle source assets and a README into a ZIP in the app cache.

## Important limitation
This is **not yet a true NBA 2K14 → NBA 2K20 Mobile converter**. A real converter needs the exact source/target mesh layouts, skeleton/vertex format, material and texture mapping, and target game's container/export method. OBJ is an interchange format and does not preserve every game-specific property. The starter deliberately does not claim that its ZIP can be installed in the game.

## Build
Open this folder in Android Studio (Giraffe or newer), allow Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s).

## Next implementation step
Add a verified NBA 2K20 Mobile model/container writer and a real export destination using `ACTION_CREATE_DOCUMENT` or AndroidX `FileProvider`. Test with a legally obtained sample asset and keep backups of game files.
