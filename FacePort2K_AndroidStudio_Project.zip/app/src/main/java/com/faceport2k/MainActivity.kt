package com.faceport2k

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.view.Gravity
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface
import java.io.*
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class MainActivity : Activity() {
    private val PICK_MODEL = 10
    private val PICK_TEXTURE = 11
    private var modelUri: Uri? = null
    private var textureUris = mutableListOf<Uri>()
    private lateinit var modelLabel: TextView
    private lateinit var textureLabel: TextView
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16,21,34)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(Color.rgb(16,21,34))
        }
        fun text(s: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false) =
            TextView(this).apply {
                text = s; textSize = size; setTextColor(color)
                if (bold) setTypeface(null, Typeface.BOLD)
                setPadding(0, 8, 0, 8)
            }
        root.addView(text("FacePort 2K", 30f, Color.rgb(230,184,74), true))
        root.addView(text("NBA 2K14 assets → 2K20 Mobile prep tool", 15f, Color.LTGRAY))
        root.addView(text("Import an OBJ mesh and its texture files. This starter builds an organized export package; it does not yet generate proprietary 2K20 IFF/model binaries.", 14f, Color.LTGRAY))
        root.addView(text("1 · 3D model", 18f, Color.WHITE, true))
        modelLabel = text("No model selected", 14f, Color.LTGRAY)
        root.addView(modelLabel)
        root.addView(button("Choose OBJ model") { pick(PICK_MODEL, "model/obj") })
        root.addView(text("2 · Textures", 18f, Color.WHITE, true))
        textureLabel = text("No textures selected", 14f, Color.LTGRAY)
        root.addView(textureLabel)
        root.addView(button("Choose texture files") {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            }
            startActivityForResult(i, PICK_TEXTURE)
        })
        root.addView(button("Validate assets") { validate() })
        root.addView(button("Export prep package (ZIP)") { exportZip() })
        status = text("Ready. Supported mesh input: Wavefront .OBJ. Textures: PNG/JPG/TGA files (copied as-is).", 14f, Color.rgb(180,200,220))
        root.addView(status)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(42,55,78))
        setOnClickListener { action() }
    }

    private fun pick(code: Int, mime: String) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = mime
        }
        startActivityForResult(i, code)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK || data == null) return
        if (requestCode == PICK_MODEL) {
            modelUri = data.data
            modelLabel.text = displayName(modelUri!!) ?: "Model selected"
        } else if (requestCode == PICK_TEXTURE) {
            textureUris.clear()
            data.clipData?.let { clip ->
                for (i in 0 until clip.itemCount) textureUris.add(clip.getItemAt(i).uri)
            } ?: data.data?.let { textureUris.add(it) }
            textureLabel.text = "${textureUris.size} texture file(s) selected"
        }
    }

    private fun displayName(uri: Uri): String? {
        return contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(android.provider.OpenableColumns.DISPLAY_NAME)) else null
        }
    }

    private fun validate() {
        val u = modelUri
        if (u == null) { status.text = "Select an OBJ model first."; return }
        try {
            val name = displayName(u) ?: "model.obj"
            if (!name.lowercase().endsWith(".obj")) {
                status.text = "Unsupported model. Choose a Wavefront .OBJ file."; return
            }
            val content = contentResolver.openInputStream(u)!!.bufferedReader().use { it.readText() }
            val vertices = content.lineSequence().count { it.trimStart().startsWith("v ") }
            val faces = content.lineSequence().count { it.trimStart().startsWith("f ") }
            status.text = "OBJ check: $vertices vertices, $faces face records, ${textureUris.size} texture(s). " +
                if (vertices > 0 && faces > 0) "Basic geometry found." else "Warning: no usable geometry detected."
        } catch (e: Exception) { status.text = "Could not read model: ${e.message}" }
    }

    private fun exportZip() {
        val u = modelUri
        if (u == null) { status.text = "Select an OBJ model first."; return }
        try {
            val out = File(cacheDir, "FacePort2K_prep.zip")
            ZipOutputStream(BufferedOutputStream(FileOutputStream(out))).use { zip ->
                addUri(zip, u, "source/model.obj")
                textureUris.forEachIndexed { i, uri ->
                    val name = (displayName(uri) ?: "texture_$i").replace(Regex("[^A-Za-z0-9._-]"), "_")
                    addUri(zip, uri, "source/textures/$name")
                }
                val readme = """
                    FacePort 2K - preparation package
                    Source mesh: Wavefront OBJ
                    Textures: copied unchanged
                    Target: NBA 2K20 Mobile (not yet converted to native game format)

                    IMPORTANT:
                    This ZIP is an asset-preparation bundle, not an installable cyberface.
                    OBJ materials/UVs may need cleanup. NBA 2K20 Mobile uses game-specific
                    model and texture containers; a verified target-format exporter is still
                    required before these assets can be installed in-game.
                """.trimIndent()
                zip.putNextEntry(ZipEntry("README.txt"))
                zip.write(readme.toByteArray(Charsets.UTF_8)); zip.closeEntry()
            }
            val share = Intent(Intent.ACTION_SEND).apply {
                type = "application/zip"
                putExtra(Intent.EXTRA_STREAM, Uri.fromFile(out))
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            // FileProvider is intentionally avoided in this starter; use Android's create-document flow in a full build.
            status.text = "Package created in app cache. Share/export UI needs FileProvider or ACTION_CREATE_DOCUMENT for Android 7+."
            Toast.makeText(this, "ZIP prepared", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { status.text = "Export failed: ${e.message}" }
    }

    private fun addUri(zip: ZipOutputStream, uri: Uri, path: String) {
        zip.putNextEntry(ZipEntry(path))
        contentResolver.openInputStream(uri)!!.use { input -> input.copyTo(zip) }
        zip.closeEntry()
    }
}
